package com.dgs.hr.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service; 
import com.dgs.hr.models.Dipendente;
import com.dgs.hr.repository.DipendenteRepository;

 

@Service
public class DipendenteService {

 

	@Autowired
	DipendenteRepository dipendenteRepository;

	public Dipendente insert(Dipendente dipendente) {
		return dipendenteRepository.save(dipendente);
	}

	public void delete(Integer id) {
		 Dipendente dipendente = dipendenteRepository.findById(id).orElse(null);
		 dipendenteRepository.delete(dipendente);
	}

	public Dipendente updateResidenza (Integer id, String residenza) {
		Dipendente dipendente = dipendenteRepository.findById(id).orElse(null);
		dipendente.setResidenza(residenza);
		return dipendenteRepository.save(dipendente);
	}

	public Dipendente updateEmail (Integer id, String email) {
		Dipendente dipendente = dipendenteRepository.findById(id).orElse(null);
		dipendente.setEmail(email);
		return dipendenteRepository.save(dipendente);
	}

	public Dipendente updateIdInquadramentoAziendale (Integer id, Integer idInquadramenteoAziendale) {
		Dipendente dipendente = dipendenteRepository.findById(id).orElse(null);
		dipendente.setIdInquadramentoAziendale(idInquadramenteoAziendale);
		return dipendenteRepository.save(dipendente);
	}

	public Dipendente getDipendente(Integer id) {
		 return dipendenteRepository.findById(id).orElse(null);

	}
}
