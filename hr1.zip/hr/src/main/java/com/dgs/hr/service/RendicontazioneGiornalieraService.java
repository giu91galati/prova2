package com.dgs.hr.service;

public class RendicontazioneGiornalieraService {

}
