package com.dgs.hr.models;

import java.io.Serializable;
import java.util.Date;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
@Entity
@Table(name="dipendenti")
public class Dipendente implements Serializable {
	
	

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;




	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;


		

		@Column(name="nome")

		private String nome;

		

		@Column(name="cognome")

		private String cognome;

		

		@Column(name="luogo_di_nascita")

		private String luogoDiNascita;

		

		@Column(name="data_di_nascita")

		private Date dataDiNascita;

		

		@Column(name="residenza")

		private String residenza;

		

		@Column(name="email")

		private String email;

		

		@Column(name="id_inquadramento_aziendale")

		private Integer idInquadramentoAziendale;

		

		public Integer getId() {

			return id;

		}

	 

		public void setId(Integer id) {

			this.id = id;

		}

	 

		public String getNome() {

			return nome;

		}

	 

		public void setNome(String nome) {

			this.nome = nome;

		}

	 

		public String getCognome() {

			return cognome;

		}

	 

		public void setCognome(String cognome) {

			this.cognome = cognome;

		}

	 

		public String getLuogoDiNascita() {

			return luogoDiNascita;

		}

	 

		public void setLuogoDiNascita(String luogoDiNascita) {

			this.luogoDiNascita = luogoDiNascita;

		}

	 

		public Date getDataDiNascita() {

			return dataDiNascita;

		}

	 

		public void setDataDiNascita(Date dataDiNascita) {

			this.dataDiNascita = dataDiNascita;

		}

	 

		public String getResidenza() {

			return residenza;

		}

	 

		public void setResidenza(String residenza) {

			this.residenza = residenza;

		}

	 

		public String getEmail() {

			return email;

		}

	 

		public void setEmail(String email) {

			this.email = email;

		}

	 

		public Integer getIdInquadramentoAziendale() {

			return idInquadramentoAziendale;

		}

	 

		public void setIdInquadramentoAziendale(Integer idInquadramentoAziendale) {

			this.idInquadramentoAziendale = idInquadramentoAziendale;

		}

	 

		public static long getSerialversionuid() {

			return serialVersionUID;

		}

	 

		@Override

		public int hashCode() {

			return Objects.hash(id);

		}

	 

		@Override

		public boolean equals(Object obj) {

			if (this == obj)

				return true;

			if (obj == null)

				return false;

			if (getClass() != obj.getClass())

				return false;

			Dipendente other = (Dipendente) obj;

			return Objects.equals(id, other.id);

		}

	 

		@Override

		public String toString() {

			return "Dipendente [id=" + id + ", nome=" + nome + ", cognome=" + cognome + ", luogoDiNascita=" + luogoDiNascita

					+ ", dataDiNascita=" + dataDiNascita + ", residenza=" + residenza + ", email=" + email

					+ ", idInquadramentoAziendale=" + idInquadramentoAziendale + "]";

		}

		

		

		

		

	}


