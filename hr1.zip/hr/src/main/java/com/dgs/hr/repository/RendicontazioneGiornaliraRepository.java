package com.dgs.hr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dgs.hr.models.RendicontazioneGiornaliera;

public interface RendicontazioneGiornaliraRepository extends JpaRepository<RendicontazioneGiornaliera, Integer> {

}
