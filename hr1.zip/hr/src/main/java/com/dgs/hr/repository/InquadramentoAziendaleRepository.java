package com.dgs.hr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dgs.hr.models.InquadramentoAziendale;

public interface InquadramentoAziendaleRepository extends JpaRepository<InquadramentoAziendale, Integer> {
	
	

}
