package com.dgs.hr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dgs.hr.models.InquadramentoAziendale;
import com.dgs.hr.repository.InquadramentoAziendaleRepository;

@Service
public class InquadramentoAziendaleService {
	
	@Autowired
	InquadramentoAziendaleRepository inquadramentoAziendaleRepository;
	
	public InquadramentoAziendale insert (InquadramentoAziendale inquadramentoAziendale) {
		return inquadramentoAziendaleRepository.save(inquadramentoAziendale);
	}
	
	public InquadramentoAziendale updateRetribuzioneLordaAnnua(Integer id,Integer nuovaRetribuzione) {
		InquadramentoAziendale inquadramentoAziendale = inquadramentoAziendaleRepository.findById(id).orElse(null);
		inquadramentoAziendale.setRetribuzioneLordaAnnua(nuovaRetribuzione);
		return inquadramentoAziendaleRepository.save(inquadramentoAziendale);
	}
	
	public InquadramentoAziendale updatePercentualeTassazione(Integer id, Integer nuovaPercentualeTassazione) {
		InquadramentoAziendale inquadramentoAziendale = inquadramentoAziendaleRepository.findById(id).orElse(null);
		inquadramentoAziendale.setPercentualeTassazione(nuovaPercentualeTassazione);
		return inquadramentoAziendaleRepository.save(inquadramentoAziendale);
		
	}
	
	

}
