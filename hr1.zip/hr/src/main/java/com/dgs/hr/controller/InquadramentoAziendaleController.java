package com.dgs.hr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dgs.hr.models.InquadramentoAziendale;
import com.dgs.hr.service.InquadramentoAziendaleService;

@RestController
@RequestMapping("/inquadramentoAziendaleRest")
@CrossOrigin
public class InquadramentoAziendaleController {
	
	@Autowired
	InquadramentoAziendaleService inquadramentoAziendaleService;
	
	
	@PostMapping("/insert")
	public ResponseEntity<InquadramentoAziendale> insert(@RequestBody InquadramentoAziendale inquadramentoAziendale) {
		System.out.println("chiamata /insert. inquadramentoAziendale: " + inquadramentoAziendale);
		InquadramentoAziendale inquadramentoAziendaleInserito = inquadramentoAziendaleService.insert(inquadramentoAziendale);
		
		return ResponseEntity.ok(inquadramentoAziendaleInserito);
	}
	
	@PutMapping("/updateRetribuzioneLordaAnnua") 
	public ResponseEntity<InquadramentoAziendale> updateRetribuzioneLordaAnnua(@RequestBody InquadramentoAziendale inquadramentoAziendale) { 
	   
		InquadramentoAziendale inquadramentoAziendaleModificato = inquadramentoAziendaleService.updateRetribuzioneLordaAnnua(inquadramentoAziendale.getId(), inquadramentoAziendale.getRetribuzioneLordaAnnua()); 
		
	    return ResponseEntity.ok(inquadramentoAziendaleModificato); 
	}
	
	@PutMapping("/updatePercentualeTassazione") 
	public ResponseEntity<InquadramentoAziendale> updatePercentualeTassazione(@RequestBody InquadramentoAziendale inquadramentoAziendale) { 
	   
		InquadramentoAziendale inquadramentoAziendaleModificato = inquadramentoAziendaleService.updatePercentualeTassazione(inquadramentoAziendale.getId(), inquadramentoAziendale.getPercentualeTassazione()); 
		
	    return ResponseEntity.ok(inquadramentoAziendaleModificato); 
	}
	
	

	

}
