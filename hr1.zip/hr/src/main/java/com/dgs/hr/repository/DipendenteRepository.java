package com.dgs.hr.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.dgs.hr.models.Dipendente;

public interface DipendenteRepository extends JpaRepository<Dipendente, Integer> {

}
