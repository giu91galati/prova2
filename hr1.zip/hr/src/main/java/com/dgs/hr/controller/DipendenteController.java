package com.dgs.hr.controller;

 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.dgs.hr.models.Dipendente;
import com.dgs.hr.service.DipendenteService;

 

@RestController
@RequestMapping("/dipendenteRest")
@CrossOrigin
public class DipendenteController {

 

	
	@Autowired
	DipendenteService dipendenteService;

	@PostMapping("/insert")
	public ResponseEntity<Dipendente> insert(@RequestBody Dipendente dipendente) {
		System.out.println("chiamata /insert. dipendente: " + dipendente);
		Dipendente dipendenteInserito = dipendenteService.insert(dipendente);

		return ResponseEntity.ok(dipendenteInserito);
	}
	
	@PutMapping("/updateResidenza") 
	public ResponseEntity<Dipendente> updateResidenza(@RequestBody Dipendente dipendente) { 
	   
		Dipendente dipendenteModificato = dipendenteService.updateResidenza(dipendente.getId(), dipendente.getResidenza()); 
		
	    return ResponseEntity.ok(dipendenteModificato); 
	}
	
	@PutMapping("/updateEmail") 
	public ResponseEntity<Dipendente> updateEmail(@RequestBody Dipendente dipendente) { 
	   
		Dipendente dipendenteModificato = dipendenteService.updateEmail(dipendente.getId(), dipendente.getEmail()); 
		
	    return ResponseEntity.ok(dipendenteModificato); 
	}
	
	
	@PutMapping("/updateInquadramentoAziendale") 
	public ResponseEntity<Dipendente> updateIdInquadramentoAziendale(@RequestBody Dipendente dipendente) { 
	   
		Dipendente dipendenteModificato = dipendenteService.updateIdInquadramentoAziendale(dipendente.getId(), dipendente.getIdInquadramentoAziendale()); 
		
	    return ResponseEntity.ok(dipendenteModificato); 
	}



 

	
}
