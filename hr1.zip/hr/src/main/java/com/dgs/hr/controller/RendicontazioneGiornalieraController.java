package com.dgs.hr.controller;

public class RendicontazioneGiornalieraController {

}
